--REPORTS

--reports for complaints and queries
select * from vw_complaints;
select * from vw_queries;

--reports for listings on which deals were made
select * from vw_Listing_User_Deal_Offering
where offer_deal_made = 'Deal made';

--offers by premium users for premium listings
select * from vw_Listing_User_Deal_Offering
where is_premium = 'Y';

--listing summary
select * from vw_Listing_Summary;

--User Stats
select * from vw_User_Activity_Summary;


