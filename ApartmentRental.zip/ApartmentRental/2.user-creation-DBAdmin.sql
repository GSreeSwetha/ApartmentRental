set serveroutput on;

Declare 
ncount number;
BEGIN
	select count(1) into ncount from all_users where username = 'RENTALADMIN';
	if (ncount>0) THEN
		dbms_output.put_line('USER RENTALADMIN ALREADY EXISTS');
	else EXECUTE IMMEDIATE 'create user rentalAdmin identified by GCQiRbpWBk1q';
		 EXECUTE IMMEDIATE 'GRANT CONNECT,RESOURCE to rentalAdmin';
		 EXECUTE IMMEDIATE 'GRANT UNLIMITED TABLESPACE TO rentalAdmin';
		 EXECUTE IMMEDIATE 'Grant create view, create sequence,create trigger, create procedure to rentalAdmin';
		 EXECUTE IMMEDIATE 'GRANT CREATE user to rentalAdmin';
         EXECUTE IMMEDIATE 'GRANT CREATE role to rentalAdmin';
		 EXECUTE IMMEDIATE 'GRANT CREATE SESSION,connect TO rentalAdmin';
		 EXECUTE IMMEDIATE 'Grant create view to rentalAdmin';
         EXECUTE IMMEDIATE 'Grant create sequence to rentalAdmin';
         EXECUTE IMMEDIATE 'Grant create trigger to rentalAdmin';
        -- EXECUTE IMMEDIATE 'Grant create index to rentalAdmin';
         EXECUTE IMMEDIATE 'Grant create any synonym to rentalAdmin';
--         EXECUTE IMMEDIATE 'Grant create package to rentalAdmin';
         EXECUTE IMMEDIATE 'Grant create procedure to rentalAdmin';
		 EXECUTE IMMEDIATE 'GRANT CREATE user to rentalAdmin';
         EXECUTE IMMEDIATE 'GRANT CREATE role to rentalAdmin';
		 EXECUTE IMMEDIATE 'GRANT CREATE SESSION,connect TO rentalAdmin';
		 end if;
end;
/

--drop user rentaladmin cascade;

---------------------------------------User Manager Creation and Role assignment-----------------------------
DECLARE nCount number;
BEGIN
SELECT count(*) into nCount FROM ALL_USERS where USERNAME = 'mguser';
IF(nCount > 0) THEN dbms_output.put_line('mguser USER ALREADY EXISTS');
ELSE EXECUTE IMMEDIATE 'create user mguser identified by setuAer26328';
     EXECUTE IMMEDIATE 'GRANT CREATE SESSION,CONNECT TO mguser';
--     EXECUTE IMMEDIATE 'Grant MANAGER to mguser';
    EXECUTE IMMEDIATE 'GRANT CREATE SYNONYM TO useller';
END IF;
EXCEPTION WHEN OTHERS THEN dbms_output.put_line(dbms_utility.format_error_backtrace);
dbms_output.put_line(SQLERRM);
ROLLBACK;
RAISE;
COMMIT;
END;
/

-------------------------------------------User Seller Creation and Role assignment-----------------------------

DECLARE nCount number;
BEGIN
SELECT count(*) into nCount FROM ALL_USERS where USERNAME = 'useller';
IF(nCount > 0) THEN dbms_output.put_line('useller USER ALREADY EXISTS');
ELSE EXECUTE IMMEDIATE 'create user useller identified by setuAer26328';
     EXECUTE IMMEDIATE 'GRANT CREATE SESSION,CONNECT TO useller';
     EXECUTE IMMEDIATE 'GRANT CREATE SYNONYM TO useller';
--     EXECUTE IMMEDIATE 'Grant seller to useller';
END IF;
EXCEPTION WHEN OTHERS THEN dbms_output.put_line(dbms_utility.format_error_backtrace);
dbms_output.put_line(SQLERRM);
ROLLBACK;
RAISE;
COMMIT;
END;
/
--drop user useller;
-------------------------------------------User Buyer Creation and Role assignment-----------------------------
DECLARE nCount number;
BEGIN
SELECT count(*) into nCount FROM ALL_USERS where USERNAME = 'ubuyer';
IF(nCount > 0) THEN dbms_output.put_line('ubuyer USER ALREADY EXISTS');
ELSE EXECUTE IMMEDIATE 'create user ubuyer identified by setuAer26328';
     EXECUTE IMMEDIATE 'GRANT CREATE SESSION,CONNECT TO ubuyer';
     EXECUTE IMMEDIATE 'GRANT CREATE SYNONYM TO ubuyer';
--     EXECUTE IMMEDIATE 'Grant Buyer to  ubuyer';
END IF;
EXCEPTION 
WHEN OTHERS THEN dbms_output.put_line(dbms_utility.format_error_backtrace);
dbms_output.put_line(SQLERRM);
ROLLBACK;
RAISE;
COMMIT;
END;
/




--GRANT ALL PRIVILEGES TO rentalAdmin;
--Grant create all synonym to rentalAdmin;
--GRANT dba TO rentalAdmin WITH ADMIN OPTION;
--
--grant select,insert,update,delete on rentalAdmin.state to mguser;
--
--select * from user_objects;
--select * from user_signup_s;
--create  synonym user_signup_s for RENTALADMIN.user_signup;