--run as DBAdmin

grant create synonym to mguser;
grant create synonym to useller;
grant create synonym to ubuyer;